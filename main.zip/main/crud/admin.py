from dataclasses import field, fields
from django.contrib import admin
from .models import ToDoListData

# Register your models here.
# admin.site.register(ToDoListData)

@admin.register(ToDoListData)
class ToDoListModel(admin.ModelAdmin):
    list_display = ('id','title','priority','tags','author')
    