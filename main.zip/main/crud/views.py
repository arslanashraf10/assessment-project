from django.shortcuts import render,HttpResponseRedirect
from django.contrib.auth import login,authenticate,logout
from django.contrib import messages
from .forms import ToDoListDataForm,signInForm,logInForm
from .models import ToDoListData
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required(login_url='/logIn/')
def index(request):
    data = ToDoListData.objects.filter(author=request.user.username)
    template_name = "crud/index.html"
    context = {
        'data':data
    }
    return render(request,template_name,context)

@login_required(login_url='/logIn/')
def addTask(request):
    if request.method == "POST":
        form = ToDoListDataForm(request.POST)
        if form.is_valid():
            task_title = form.cleaned_data['title']
            task_priority = form.cleaned_data['priority']
            task_tags = form.cleaned_data['tags']
            task = ToDoListData(title = task_title,priority=task_priority,tags=task_tags,author=request.user.username)
            task.save()
            form = ToDoListDataForm()
    else:
        form = ToDoListDataForm()
    template_name = "crud/addTask.html"
    context = {
        'form':form,
    }
    return render(request,template_name,context)

#This function will delete data
@login_required(login_url='/logIn/')
def deleteTask(request,id):
    data = ToDoListData.objects.get(pk=id)
    data.delete()
    messages.success(request,"Your task has been deleted successfully")
    return HttpResponseRedirect("/")

@login_required(login_url='/logIn/')
def updateTask(request,id):
    if request.method=="POST":
        form=ToDoListDataForm(request.POST)
        if form.is_valid():
            task_title = form.cleaned_data['title']
            task_priority = form.cleaned_data['priority']
            task_tags = form.cleaned_data['tags']
            task = ToDoListData(title = task_title,priority=task_priority,tags=task_tags,author=request.user.username)
            task.save()
            messages.success(request,"Your task has been updated successfully")

    else:
        data =ToDoListData.objects.get(pk=id)
        form = ToDoListDataForm(initial={
        'title':data.title
    })
    return render(request,"crud/updateTask.html",{
        'form':form,
        'id':id,
    })

    
#Sign in page
def signIn_view(request):
    if request.method=="POST":
        fm=signInForm(request.POST)
        if fm.is_valid():
            fm.save()
            return HttpResponseRedirect('/logIn/')
    else:
        fm=signInForm()
    return render(request,'crud/signIn.html',{
        'form':fm
    })



def logIn_view(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('/')
    else:
        if request.method=="POST":
            fm=logInForm(request=request,data=request.POST)
            if fm.is_valid():
                uname=fm.cleaned_data['username']
                upass=fm.cleaned_data['password']
                user=authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    return HttpResponseRedirect('/')
        else:      
            fm=logInForm()
        return render(request,'crud/login.html',{
            'form':fm
        })

@login_required(login_url='/logIn/')
def logOut_view(request):
    logout(request)
    return HttpResponseRedirect('/logIn/')