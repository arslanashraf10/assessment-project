from operator import mod
from django.db import models

# Create your models here.
class ToDoListData(models.Model):
    PRIORITY_CHOICES = (
        ("high", "HIGH"),
        ("medium", "MEDIUM"),
        ("low", "LOW"),
        )
    title = models.CharField(max_length=70,default='')
    priority = models.CharField(max_length=20,choices=PRIORITY_CHOICES,default='high')
    author = models.CharField(max_length=70,default='')
    tags = models.CharField(max_length=70,default='')
    

    def __str__(self):
        return f"{self.title}"