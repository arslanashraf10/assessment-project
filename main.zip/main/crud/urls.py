
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index ,name='index'),
    path('addTask/', views.addTask ,name="addTask"),
    path('task/<int:id>/',views.updateTask,name="update"),
    path('<int:id>/', views.deleteTask ,name="delete"),
    path('signIn/',views.signIn_view,name='signIn'),
    path('logIn/',views.logIn_view,name='logIn'),
    path('logOut/',views.logOut_view,name='logOut'),
    
]
